package dev.poplarcompat.paper;

import dev.poplarcompat.common.PoplarProtocol;
import dev.poplarcompat.common.PoplarProtocol.Message;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.plugin.java.JavaPlugin;

/** Phase 2/3 proof-of-concept transport and one-position Poplar plank update. */
public final class PoplarCompatPaperPlugin extends JavaPlugin implements Listener, PluginMessageListener {
    private final Set<UUID> compatiblePlayers = new HashSet<>();

    @Override public void onEnable() {
        getServer().getMessenger().registerOutgoingPluginChannel(this, PoplarProtocol.CHANNEL);
        getServer().getMessenger().registerIncomingPluginChannel(this, PoplarProtocol.CHANNEL, this::onPluginMessageReceived);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("PoplarCompat Paper transport enabled on " + getServer().getVersion());
    }

    @Override public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) if (compatiblePlayers.contains(player.getUniqueId()))
            player.sendPluginMessage(this, PoplarProtocol.CHANNEL, PoplarProtocol.worldClear());
        compatiblePlayers.clear();
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> sendHello(event.getPlayer()), 20L);
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) { compatiblePlayers.remove(event.getPlayer().getUniqueId()); }

    @EventHandler public void onPlace(BlockPlaceEvent event) {
        if (isPoplar(event.getBlock())) broadcastSet(event.getBlock());
    }
    @EventHandler public void onBreak(BlockBreakEvent event) {
        if (isPoplar(event.getBlock())) broadcastRemove(event.getBlock());
    }

    private void sendHello(Player player) {
        if (player.isOnline()) player.sendPluginMessage(this, PoplarProtocol.CHANNEL,
                PoplarProtocol.serverHello(getPluginMeta().getVersion(), 1));
    }

    @Override public void onPluginMessageReceived(String channel, Player player, byte[] bytes) {
        if (!PoplarProtocol.CHANNEL.equals(channel)) return;
        try {
            Message message = PoplarProtocol.read(bytes);
            if (message.version() != PoplarProtocol.VERSION) return;
            if (message.type() == PoplarProtocol.Type.CLIENT_HELLO) {
                compatiblePlayers.add(player.getUniqueId());
                player.sendPluginMessage(this, PoplarProtocol.CHANNEL, PoplarProtocol.serverStatus("compatible"));
                getLogger().info("PoplarCompat client handshake completed for " + player.getName());
            }
        } catch (IOException | RuntimeException error) {
            getLogger().warning("Rejected malformed PoplarCompat payload from " + player.getName() + ": " + error.getMessage());
        }
    }

    private void broadcastSet(Block block) {
        String dimension = block.getWorld().getKey().toString();
        String state = block.getBlockData().getAsString(true);
        byte[] payload = PoplarProtocol.blockSet(dimension, block.getX(), block.getY(), block.getZ(), state);
        for (Player player : Bukkit.getOnlinePlayers()) if (compatiblePlayers.contains(player.getUniqueId())
                && player.getWorld().equals(block.getWorld()) && player.getLocation().distanceSquared(block.getLocation()) < 256 * 256)
            player.sendPluginMessage(this, PoplarProtocol.CHANNEL, payload);
    }
    private void broadcastRemove(Block block) {
        byte[] payload = PoplarProtocol.blockRemove(block.getWorld().getKey().toString(), block.getX(), block.getY(), block.getZ());
        for (Player player : Bukkit.getOnlinePlayers()) if (compatiblePlayers.contains(player.getUniqueId())
                && player.getWorld().equals(block.getWorld()) && player.getLocation().distanceSquared(block.getLocation()) < 256 * 256)
            player.sendPluginMessage(this, PoplarProtocol.CHANNEL, payload);
    }

    private static boolean isPoplar(Block block) { return block.getType().name().startsWith("POPLAR_"); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("poplarcompat")) return false;
        if (args.length > 0 && args[0].equalsIgnoreCase("status")) {
            sender.sendMessage("PoplarCompat compatible clients: " + compatiblePlayers.size()); return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("debug") && args.length > 1) {
            Player player = Bukkit.getPlayerExact(args[1]);
            sender.sendMessage(player == null ? "Player not found" : "handshake=" + compatiblePlayers.contains(player.getUniqueId())); return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("resend")) {
            Player player = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : (sender instanceof Player p ? p : null);
            if (player == null) { sender.sendMessage("Usage: /poplarcompat resend [player]"); return true; }
            Block target = player.getTargetBlockExact(8);
            if (target == null || !isPoplar(target)) { sender.sendMessage("Look at a Poplar block within 8 blocks."); return true; }
            if (compatiblePlayers.contains(player.getUniqueId())) { broadcastSet(target); sender.sendMessage("Sent " + target.getBlockData().getAsString(true) + " to " + player.getName()); }
            else sender.sendMessage("That player has not completed the PoplarCompat handshake.");
            return true;
        }
        sender.sendMessage("/poplarcompat status | debug <player> | resend [player]"); return true;
    }
}
