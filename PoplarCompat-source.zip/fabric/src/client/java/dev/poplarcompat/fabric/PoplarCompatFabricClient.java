package dev.poplarcompat.fabric;

import dev.poplarcompat.common.PoplarProtocol;
import dev.poplarcompat.common.PoplarProtocol.Message;
import java.io.IOException;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.NoteBlock;
import net.minecraft.block.enums.NoteBlockInstrument;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Fabric 1.21.11 client half. Phase 2/3 keeps a position map and swaps one baked carrier model. */
public final class PoplarCompatFabricClient implements ClientModInitializer {
    public static final String MOD_ID = "poplarcompat";
    public static final String MOD_VERSION = "0.1.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final Identifier CHANNEL = Identifier.of("poplarcompat", "main");
    private static final CustomPayload.Id<PoplarPayload> PAYLOAD_ID = new CustomPayload.Id<>(CHANNEL);
    private static final PacketCodec<PacketByteBuf, PoplarPayload> PAYLOAD_CODEC = PacketCodec.of(
            (payload, buf) -> buf.writeBytes(payload.data()),
            buf -> {
                byte[] data = new byte[buf.readableBytes()];
                buf.readBytes(data);
                return new PoplarPayload(data);
            });
    private static final Map<String, Map<Long, String>> VIRTUAL_STATES = new ConcurrentHashMap<>();
    private static final java.util.Set<Long> RENDER_LOGGED = ConcurrentHashMap.newKeySet();
    private static volatile boolean handshakeComplete;

    @Override public void onInitializeClient() {
        // The same payload travels in both directions: the server sends
        // SERVER_HELLO/status/update frames and the client answers with
        // CLIENT_HELLO. Fabric keeps separate codecs for S2C and C2S, so the
        // codec must be registered in both registries before either handler
        // or sender is used.
        PayloadTypeRegistry.playS2C().register(PAYLOAD_ID, PAYLOAD_CODEC);
        PayloadTypeRegistry.playC2S().register(PAYLOAD_ID, PAYLOAD_CODEC);
        ClientPlayNetworking.registerGlobalReceiver(PAYLOAD_ID, (payload, context) -> {
            MinecraftClient client = context.client();
            client.execute(() -> receive(client, context.responseSender(), payload.data()));
        });
        LOGGER.info("PoplarCompat client loaded; waiting for a PoplarCompat server handshake");
    }

    private static void receive(MinecraftClient client, PacketSender sender, byte[] bytes) {
        try {
            Message message = PoplarProtocol.read(bytes);
            if (message.version() != PoplarProtocol.VERSION) return;
            switch (message.type()) {
                case SERVER_HELLO -> {
                    sender.sendPacket(new PoplarPayload(PoplarProtocol.clientHello(MOD_VERSION, 1)));
                    LOGGER.info("Successfully connected to PoplarCompat server");
                }
                case SERVER_STATUS -> {
                    handshakeComplete = "compatible".equals(message.text());
                    LOGGER.info("PoplarCompat handshake status: {}", message.text());
                }
                case BLOCK_SET -> {
                    if (!handshakeComplete) handshakeComplete = true;
                    String dimension = normalizeDimension(message.dimension());
                    VIRTUAL_STATES.computeIfAbsent(dimension, ignored -> new ConcurrentHashMap<>())
                            .put(BlockPos.asLong(message.x(), message.y(), message.z()), message.text());
                    LOGGER.info("Received PoplarCompat block update: {} {} {} {} ({})", dimension,
                            message.x(), message.y(), message.z(), message.text());
                    dirty(client, message.x(), message.y(), message.z());
                }
                case BLOCK_REMOVE -> {
                    Map<Long, String> states = VIRTUAL_STATES.get(normalizeDimension(message.dimension()));
                    if (states != null) states.remove(BlockPos.asLong(message.x(), message.y(), message.z()));
                    dirty(client, message.x(), message.y(), message.z());
                }
                case WORLD_CLEAR -> {
                    VIRTUAL_STATES.clear();
                    RENDER_LOGGED.clear();
                    handshakeComplete = false;
                    if (client.worldRenderer != null) client.worldRenderer.reload();
                }
                default -> { }
            }
        } catch (IOException | RuntimeException error) {
            LOGGER.warn("Ignored malformed PoplarCompat payload", error);
        }
    }

    private static void dirty(MinecraftClient client, int x, int y, int z) {
        if (client.worldRenderer != null) client.worldRenderer.scheduleChunkRenders3x3x3(x >> 4, y >> 4, z >> 4);
    }

    public static boolean hasVirtualPoplar(BlockPos pos, MinecraftClient client) {
        if (!handshakeComplete || client.world == null) return false;
        Map<Long, String> states = VIRTUAL_STATES.get(normalizeDimension(client.world.getRegistryKey().getValue().toString()));
        boolean present = states != null && states.containsKey(pos.asLong());
        if (present && RENDER_LOGGED.add(pos.asLong()))
            LOGGER.info("Applying Poplar model at {}", pos);
        return present;
    }

    private static String normalizeDimension(String dimension) {
        if (dimension == null) return "";
        String normalized = dimension.toLowerCase(Locale.ROOT);
        return normalized.startsWith("minecraft:") ? normalized.substring("minecraft:".length()) : normalized;
    }

    /** Existing note-block state is a model carrier; no networked custom block is registered. */
    public static BlockState carrierState() {
        return Blocks.NOTE_BLOCK.getDefaultState()
                .with(NoteBlock.INSTRUMENT, NoteBlockInstrument.HARP)
                .with(NoteBlock.NOTE, 0)
                .with(NoteBlock.POWERED, false);
    }

    public static void clearForDisconnect() {
        VIRTUAL_STATES.clear();
        handshakeComplete = false;
    }

    private record PoplarPayload(byte[] data) implements CustomPayload {
        @Override public Id<? extends CustomPayload> getId() { return PAYLOAD_ID; }
    }
}
