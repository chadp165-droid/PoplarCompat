package dev.poplarcompat.fabric.mixin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.client.render.chunk.BlockBufferAllocatorStorage;

/** Diagnostic hook for instances that replace or bypass the vanilla section compiler. */
@Mixin(targets = "net.minecraft.client.render.chunk.ChunkBuilder$BuiltChunk$RebuildTask")
public abstract class RebuildTaskMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("poplarcompat");
    private static volatile boolean LOGGED;

    @Inject(method = "run", at = @At("HEAD"))
    private void poplarcompat$rebuildStarted(BlockBufferAllocatorStorage buffers, CallbackInfoReturnable<?> cir) {
        if (!LOGGED) {
            LOGGED = true;
            LOGGER.info("Poplar chunk rebuild task hook active");
        }
    }
}
