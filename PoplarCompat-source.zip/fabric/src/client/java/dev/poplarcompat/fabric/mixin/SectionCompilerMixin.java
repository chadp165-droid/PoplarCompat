package dev.poplarcompat.fabric.mixin;

import dev.poplarcompat.fabric.PoplarCompatFabricClient;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.chunk.ChunkRendererRegion;
import net.minecraft.client.render.chunk.SectionBuilder;
import net.minecraft.client.render.model.BlockStateModel;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Redirects only the position-aware chunk compiler model lookup. */
@Mixin(SectionBuilder.class)
public abstract class SectionCompilerMixin {
    private static final ThreadLocal<BlockPos> POPLARCOMPAT_POSITION = new ThreadLocal<>();

    @Redirect(method = "build", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/chunk/ChunkRendererRegion;getBlockState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;"))
    private BlockState poplarcompat$capturePosition(ChunkRendererRegion region, BlockPos pos) {
        POPLARCOMPAT_POSITION.set(pos.toImmutable());
        return region.getBlockState(pos);
    }

    @Redirect(method = "build", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/block/BlockRenderManager;getModel(Lnet/minecraft/block/BlockState;)Lnet/minecraft/client/render/model/BlockStateModel;"))
    private BlockStateModel poplarcompat$chooseModel(BlockRenderManager manager, BlockState original) {
        BlockPos pos = POPLARCOMPAT_POSITION.get();
        POPLARCOMPAT_POSITION.remove();
        MinecraftClient client = MinecraftClient.getInstance();
        if (pos != null && PoplarCompatFabricClient.hasVirtualPoplar(pos, client))
            return manager.getModel(PoplarCompatFabricClient.carrierState());
        return manager.getModel(original);
    }
}
