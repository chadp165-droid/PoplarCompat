package dev.poplarcompat.common;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Small versioned binary protocol shared by the Paper plugin and Fabric client. */
public final class PoplarProtocol {
    public static final String CHANNEL = "poplarcompat:main";
    public static final int VERSION = 1;
    private static final int MAGIC = 0x50434D50; // PCMP
    private static final int MAX_FRAME = 16 * 1024;

    public enum Type { SERVER_HELLO(1), CLIENT_HELLO(2), SERVER_STATUS(3), BLOCK_SET(4), BLOCK_REMOVE(5), WORLD_CLEAR(6);
        public final int id; Type(int id) { this.id = id; }
        public static Type of(int id) { for (Type t : values()) if (t.id == id) return t; return null; }
    }

    public record Message(Type type, int version, String text, String dimension, int x, int y, int z) {}

    private PoplarProtocol() {}

    public static byte[] serverHello(String pluginVersion, int features) { return hello(Type.SERVER_HELLO, pluginVersion, features); }
    public static byte[] clientHello(String modVersion, int features) { return hello(Type.CLIENT_HELLO, modVersion, features); }
    public static byte[] serverStatus(String status) { return write(out -> { header(out, Type.SERVER_STATUS); string(out, status); }); }
    public static byte[] blockSet(String dimension, int x, int y, int z, String state) {
        return write(out -> { header(out, Type.BLOCK_SET); string(out, dimension); out.writeInt(x); out.writeInt(y); out.writeInt(z); string(out, state); });
    }
    public static byte[] blockRemove(String dimension, int x, int y, int z) {
        return write(out -> { header(out, Type.BLOCK_REMOVE); string(out, dimension); out.writeInt(x); out.writeInt(y); out.writeInt(z); });
    }
    public static byte[] worldClear() { return write(out -> header(out, Type.WORLD_CLEAR)); }

    public static Message read(byte[] bytes) throws IOException {
        if (bytes == null || bytes.length > MAX_FRAME) throw new IOException("PoplarCompat frame exceeds limit");
        try (DataInputStream in = new DataInputStream(new java.io.ByteArrayInputStream(bytes))) {
            if (in.readInt() != MAGIC) throw new IOException("Invalid PoplarCompat magic");
            int version = in.readUnsignedByte();
            Type type = Type.of(in.readUnsignedByte());
            if (type == null) throw new IOException("Unknown PoplarCompat message type");
            return switch (type) {
                case SERVER_HELLO, CLIENT_HELLO -> {
                    String text = readString(in);
                    in.readInt(); // feature flags are reserved for protocol negotiation
                    yield new Message(type, version, text, null, 0, 0, 0);
                }
                case SERVER_STATUS -> new Message(type, version, readString(in), null, 0, 0, 0);
                case BLOCK_SET -> {
                    String dimension = readString(in);
                    int x = in.readInt();
                    int y = in.readInt();
                    int z = in.readInt();
                    String state = readString(in);
                    yield new Message(type, version, state, dimension, x, y, z);
                }
                case BLOCK_REMOVE -> {
                    String dimension = readString(in);
                    int x = in.readInt();
                    int y = in.readInt();
                    int z = in.readInt();
                    yield new Message(type, version, null, dimension, x, y, z);
                }
                case WORLD_CLEAR -> new Message(type, version, null, null, 0, 0, 0);
            };
        }
    }

    private static byte[] hello(Type type, String value, int features) { return write(out -> { header(out, type); string(out, value); out.writeInt(features); }); }
    private interface Writer { void write(DataOutputStream out) throws IOException; }
    private static byte[] write(Writer writer) {
        try { var bytes = new java.io.ByteArrayOutputStream(); var out = new DataOutputStream(bytes); writer.write(out); out.flush(); return bytes.toByteArray(); }
        catch (IOException e) { throw new IllegalStateException(e); }
    }
    private static void header(DataOutput out, Type type) throws IOException { out.writeInt(MAGIC); out.writeByte(VERSION); out.writeByte(type.id); }
    private static void string(DataOutput out, String value) throws IOException {
        byte[] bytes = value == null ? new byte[0] : value.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > 4096) throw new IOException("PoplarCompat string too long");
        out.writeShort(bytes.length); out.write(bytes);
    }
    private static String readString(DataInput in) throws IOException {
        int length = in.readUnsignedShort(); if (length > 4096) throw new IOException("PoplarCompat string too long");
        byte[] bytes = new byte[length]; in.readFully(bytes); return new String(bytes, StandardCharsets.UTF_8);
    }
}
