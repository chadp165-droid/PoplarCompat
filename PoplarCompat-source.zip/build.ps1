$ErrorActionPreference = "Stop"
$gradle = Join-Path $PSScriptRoot "gradle-9.7.1\bin\gradle.bat"
if (-not (Test-Path $gradle)) { throw "Gradle 9.7.1 is missing. Install it or run the equivalent Gradle command." }
& $gradle verifyArtifacts --no-daemon --console=plain
