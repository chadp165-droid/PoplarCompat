param(
    [Parameter(Mandatory=$true)]
    [string]$SourceRoot
)
$ErrorActionPreference = "Stop"
$source = (Resolve-Path $SourceRoot).Path
$destination = Join-Path $PSScriptRoot "..\fabric\src\main\resources\assets\minecraft"
New-Item -ItemType Directory -Force $destination | Out-Null
$sourceAssets = Join-Path $source "assets\minecraft"
if (-not (Test-Path $sourceAssets)) { throw "Expected $sourceAssets" }
Copy-Item (Join-Path $sourceAssets "*") $destination -Recurse -Force
Write-Host "Imported Poplar client assets from $sourceAssets"
